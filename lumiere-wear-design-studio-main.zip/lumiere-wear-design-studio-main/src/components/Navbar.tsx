import { useState } from "react";
import { Search, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Shop", path: "/shop" },
    { name: "About", path: "/about" },
    { name: "Lookbook", path: "/lookbook" },
    { name: "Contact", path: "/contact" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </Button>

          {/* Desktop Navigation - Left */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.slice(0, 2).map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`font-inter text-sm tracking-wide transition-colors duration-200 hover:text-accent ${
                  isActive(item.path) ? "text-primary font-medium" : "text-foreground"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* Brand Logo */}
          <Link to="/" className="font-playfair text-xl tracking-wider text-primary">
            LUMIÈRE WEAR
          </Link>

          {/* Desktop Navigation - Right */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.slice(2).map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`font-inter text-sm tracking-wide transition-colors duration-200 hover:text-accent ${
                  isActive(item.path) ? "text-primary font-medium" : "text-foreground"
                }`}
              >
                {item.name}
              </Link>
            ))}
            <Button variant="ghost" size="icon">
              <Search className="h-4 w-4" />
            </Button>
          </div>

          {/* Mobile Search */}
          <Button variant="ghost" size="icon" className="md:hidden">
            <Search className="h-4 w-4" />
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-border bg-background">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`block px-3 py-2 text-sm font-inter tracking-wide transition-colors duration-200 ${
                    isActive(item.path) 
                      ? "text-primary font-medium bg-secondary/50" 
                      : "text-foreground hover:text-accent hover:bg-secondary/30"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;