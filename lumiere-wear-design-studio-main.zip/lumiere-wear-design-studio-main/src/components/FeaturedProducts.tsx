import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import product1 from "@/assets/product1-trousers.jpg";
import product2 from "@/assets/product2-sweater.jpg";
import product3 from "@/assets/product3-dress.jpg";
import product4 from "@/assets/product4-tank.jpg";
import product5 from "@/assets/product5-slip-dress.jpg";
import product6 from "@/assets/product6-jewelry.jpg";

const FeaturedProducts = () => {
const products = [
    {
      id: 1,
      name: "Sage Wide-Leg Trousers",
      price: "$185",
      image: product1,
      description: "Elegant high-waisted trousers in sage green"
    },
    {
      id: 2,
      name: "Cashmere Sweater",
      price: "$220",
      image: product2,
      description: "Luxurious cream cashmere knit"
    },
    {
      id: 3,
      name: "Silk Slip Dress",
      price: "$165",
      image: product3,
      description: "Minimalist black silk evening dress"
    },
    {
      id: 4,
      name: "Classic Ribbed Tank",
      price: "$25",
      image: product4,
      description: "Essential women's tops for everyday wear"
    },
    {
      id: 5,
      name: "Satin Slip Dress",
      price: "$70",
      image: product5,
      description: "Elegant women's dress for special occasions"
    },
    {
      id: 6,
      name: "Women's Jewelry",
      price: "$25",
      image: product6,
      description: "Delicate accessories to complete your look"
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-4">
            FEATURED PRODUCTS
          </h2>
          <p className="font-inter text-muted-foreground max-w-2xl mx-auto">
            Carefully curated pieces that embody our commitment to timeless elegance and exceptional quality
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {products.map((product) => (
            <Card key={product.id} className="group cursor-pointer border-0 shadow-none bg-transparent">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-lg mb-4">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-96 object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />
                </div>
                <div className="text-center space-y-2">
                  <h3 className="font-playfair text-xl font-medium text-primary">
                    {product.name}
                  </h3>
                  <p className="font-inter text-sm text-muted-foreground">
                    {product.description}
                  </p>
                  <p className="font-inter text-lg font-medium text-foreground">
                    {product.price}
                  </p>
                  <Button 
                    variant="elegant" 
                    size="sm" 
                    className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="font-inter">
            View All Products
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;