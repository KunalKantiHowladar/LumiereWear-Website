import { Button } from "@/components/ui/button";
import heroModel from "@/assets/hero-model.jpg";

const Hero = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroModel}
          alt="Elegant fashion model"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/20" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-primary max-w-4xl mx-auto px-4">
        <h1 className="font-playfair text-5xl md:text-7xl font-bold mb-6 tracking-wide">
          NEW ARRIVALS
        </h1>
        <p className="font-inter text-lg md:text-xl mb-8 max-w-2xl mx-auto leading-relaxed opacity-90">
          Discover our latest collection of timeless pieces designed for the modern woman
        </p>
        <Button variant="hero" size="xl" className="font-inter font-medium">
          SHOP NOW
        </Button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="animate-bounce">
          <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
            <div className="w-1 h-3 bg-primary rounded-full mt-2" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;