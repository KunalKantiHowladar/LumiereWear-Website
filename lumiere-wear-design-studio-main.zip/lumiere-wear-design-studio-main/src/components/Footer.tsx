import { Instagram, Facebook } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Footer = () => {
  return (
    <footer className="bg-secondary border-t border-border">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <h3 className="font-playfair text-2xl font-bold text-primary mb-4">
              LUMIÈRE WEAR
            </h3>
            <p className="font-inter text-muted-foreground mb-6 max-w-md">
              Timeless elegance meets contemporary design. Crafting pieces that celebrate the modern woman's journey.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Facebook className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-inter font-medium text-foreground mb-4">Quick Links</h4>
            <ul className="space-y-2 font-inter text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-accent transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Size Guide</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Care Instructions</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Returns</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Shipping</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-inter font-medium text-foreground mb-4">Stay Updated</h4>
            <p className="font-inter text-sm text-muted-foreground mb-4">
              Subscribe for exclusive offers and new arrivals.
            </p>
            <div className="space-y-2">
              <Input 
                type="email" 
                placeholder="Enter your email"
                className="font-inter text-sm"
              />
              <Button variant="default" size="sm" className="w-full">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8 text-center">
          <p className="font-inter text-sm text-muted-foreground">
            © 2024 Lumière Wear. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;