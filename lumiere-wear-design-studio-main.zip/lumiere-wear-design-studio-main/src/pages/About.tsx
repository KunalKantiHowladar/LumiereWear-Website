import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
            About Lumière Wear
          </h1>
          <p className="font-inter text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Born from a vision to redefine contemporary elegance, Lumière Wear celebrates the modern woman's journey with timeless pieces that transcend seasons and trends.
          </p>
        </div>

        {/* Story Section */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="font-playfair text-3xl font-bold text-primary mb-6">
              Our Story
            </h2>
            <div className="space-y-4 font-inter text-muted-foreground">
              <p>
                Founded in 2024, Lumière Wear emerged from a simple belief: that fashion should be both beautiful and meaningful. Our founder, inspired by the interplay of light and shadow in art, sought to create clothing that captures the luminous spirit of the modern woman.
              </p>
              <p>
                Each piece in our collection is thoughtfully designed to move with you through life's moments – from quiet morning coffees to important presentations, from intimate dinners to spontaneous adventures.
              </p>
              <p>
                We believe in slow fashion, quality craftsmanship, and the power of feeling confident in what you wear.
              </p>
            </div>
          </div>
          <div className="bg-secondary/50 h-96 rounded-lg flex items-center justify-center">
            <p className="font-playfair text-2xl text-muted-foreground">Brand Story Image</p>
          </div>
        </div>

        {/* Values Section */}
        <div className="mb-16">
          <h2 className="font-playfair text-3xl font-bold text-primary text-center mb-12">
            Our Values
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="w-8 h-8 bg-accent rounded-full"></div>
              </div>
              <h3 className="font-playfair text-xl font-medium text-primary mb-3">
                Sustainability
              </h3>
              <p className="font-inter text-muted-foreground">
                Committed to ethical production and environmentally conscious materials that respect our planet.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="w-8 h-8 bg-accent rounded-full"></div>
              </div>
              <h3 className="font-playfair text-xl font-medium text-primary mb-3">
                Quality
              </h3>
              <p className="font-inter text-muted-foreground">
                Exceptional craftsmanship and attention to detail in every stitch, ensuring pieces that last.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="w-8 h-8 bg-accent rounded-full"></div>
              </div>
              <h3 className="font-playfair text-xl font-medium text-primary mb-3">
                Elegance
              </h3>
              <p className="font-inter text-muted-foreground">
                Timeless designs that celebrate femininity and empower confidence in every woman.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-secondary/30 rounded-lg p-12">
          <h2 className="font-playfair text-3xl font-bold text-primary mb-4">
            Join Our Journey
          </h2>
          <p className="font-inter text-muted-foreground mb-8 max-w-2xl mx-auto">
            Be part of a community that values conscious fashion, timeless style, and authentic self-expression.
          </p>
          <Button variant="default" size="lg" className="font-inter">
            Explore Our Collection
          </Button>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default About;