import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import product1 from "@/assets/product1-trousers.jpg";
import product2 from "@/assets/product2-sweater.jpg";
import product3 from "@/assets/product3-dress.jpg";

const Lookbook = () => {
  const collections = [
    {
      id: 1,
      title: "Spring Awakening",
      subtitle: "Fresh beginnings in soft palettes",
      image: product2,
      description: "Embrace the season with flowing fabrics and gentle hues that capture the essence of renewal."
    },
    {
      id: 2,
      title: "Urban Elegance", 
      subtitle: "Sophisticated city living",
      image: product3,
      description: "Effortless pieces designed for the modern woman navigating city life with grace and confidence."
    },
    {
      id: 3,
      title: "Timeless Classics",
      subtitle: "Enduring style beyond trends",
      image: product1,
      description: "Investment pieces that transcend seasons, crafted for the woman who values lasting quality."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
            Lookbook
          </h1>
          <p className="font-inter text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover how our pieces come together to create looks that inspire confidence and celebrate individuality.
          </p>
        </div>

        {/* Collections */}
        <div className="space-y-24">
          {collections.map((collection, index) => (
            <div key={collection.id} className={`grid lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
              <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                <div className="relative overflow-hidden rounded-lg shadow-elegant">
                  <img
                    src={collection.image}
                    alt={collection.title}
                    className="w-full h-96 lg:h-[500px] object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
              </div>
              <div className={`space-y-6 ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                <div>
                  <p className="font-inter text-sm tracking-wider text-accent uppercase mb-2">
                    Collection
                  </p>
                  <h2 className="font-playfair text-3xl lg:text-4xl font-bold text-primary mb-3">
                    {collection.title}
                  </h2>
                  <h3 className="font-inter text-xl text-muted-foreground mb-6">
                    {collection.subtitle}
                  </h3>
                </div>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  {collection.description}
                </p>
                <Button variant="outline" size="lg" className="font-inter">
                  Explore Collection
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Style Gallery */}
        <div className="mt-24">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-3xl font-bold text-primary mb-4">
              Style Inspiration
            </h2>
            <p className="font-inter text-muted-foreground max-w-2xl mx-auto">
              See how our community styles their favorite pieces
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="group relative overflow-hidden rounded-lg bg-secondary/30 aspect-[3/4]">
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="font-playfair text-lg text-muted-foreground">
                    Style {item}
                  </p>
                </div>
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-24 text-center bg-secondary/30 rounded-lg p-12">
          <h2 className="font-playfair text-3xl font-bold text-primary mb-4">
            Create Your Own Story
          </h2>
          <p className="font-inter text-muted-foreground mb-8 max-w-2xl mx-auto">
            Share your Lumière Wear looks with our community and inspire others with your unique style.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="default" size="lg" className="font-inter">
              Shop the Look
            </Button>
            <Button variant="outline" size="lg" className="font-inter">
              Share Your Style
            </Button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Lookbook;