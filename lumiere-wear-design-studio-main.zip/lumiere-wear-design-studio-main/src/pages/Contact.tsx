import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

const Contact = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-6">
            Get In Touch
          </h1>
          <p className="font-inter text-lg text-muted-foreground max-w-2xl mx-auto">
            We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="shadow-elegant">
            <CardHeader>
              <CardTitle className="font-playfair text-2xl text-primary">
                Send us a message
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="font-inter text-sm font-medium text-foreground">
                    First Name
                  </label>
                  <Input placeholder="Your first name" />
                </div>
                <div className="space-y-2">
                  <label className="font-inter text-sm font-medium text-foreground">
                    Last Name
                  </label>
                  <Input placeholder="Your last name" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="font-inter text-sm font-medium text-foreground">
                  Email
                </label>
                <Input type="email" placeholder="your.email@example.com" />
              </div>
              <div className="space-y-2">
                <label className="font-inter text-sm font-medium text-foreground">
                  Subject
                </label>
                <Input placeholder="What's this about?" />
              </div>
              <div className="space-y-2">
                <label className="font-inter text-sm font-medium text-foreground">
                  Message
                </label>
                <Textarea 
                  placeholder="Tell us more about your inquiry..."
                  className="min-h-32"
                />
              </div>
              <Button variant="default" size="lg" className="w-full font-inter">
                Send Message
              </Button>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-inter font-medium text-foreground mb-1">
                      Email
                    </h3>
                    <p className="font-inter text-muted-foreground">
                      hello@lumierewear.com
                    </p>
                    <p className="font-inter text-muted-foreground">
                      support@lumierewear.com
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-inter font-medium text-foreground mb-1">
                      Phone
                    </h3>
                    <p className="font-inter text-muted-foreground">
                      +1 (555) 123-4567
                    </p>
                    <p className="font-inter text-muted-foreground">
                      +1 (555) 123-4568
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-inter font-medium text-foreground mb-1">
                      Address
                    </h3>
                    <p className="font-inter text-muted-foreground">
                      123 Fashion Avenue<br />
                      New York, NY 10001<br />
                      United States
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-inter font-medium text-foreground mb-1">
                      Business Hours
                    </h3>
                    <p className="font-inter text-muted-foreground">
                      Monday - Friday: 9:00 AM - 6:00 PM<br />
                      Saturday: 10:00 AM - 4:00 PM<br />
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="mt-16 text-center bg-secondary/30 rounded-lg p-12">
          <h2 className="font-playfair text-3xl font-bold text-primary mb-4">
            Stay Connected
          </h2>
          <p className="font-inter text-muted-foreground mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for exclusive offers, style tips, and first access to new collections.
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <Input 
              type="email" 
              placeholder="Enter your email"
              className="flex-1"
            />
            <Button variant="default">
              Subscribe
            </Button>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Contact;