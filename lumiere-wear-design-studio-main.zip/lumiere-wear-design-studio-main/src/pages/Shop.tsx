import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import product1 from "@/assets/product1-trousers.jpg";
import product2 from "@/assets/product2-sweater.jpg";
import product3 from "@/assets/product3-dress.jpg";

const Shop = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", "Tops", "Bottoms", "Dresses", "Outerwear"];

  const products = [
    {
      id: 1,
      name: "Sage Wide-Leg Trousers",
      price: "$185",
      category: "Bottoms",
      image: product1,
      isNew: true
    },
    {
      id: 2,
      name: "Cashmere Sweater",
      price: "$220",
      category: "Tops",
      image: product2,
      isNew: true
    },
    {
      id: 3,
      name: "Silk Slip Dress",
      price: "$165",
      category: "Dresses",
      image: product3,
      isNew: false
    },
    {
      id: 4,
      name: "Linen Blazer",
      price: "$195",
      category: "Outerwear",
      image: product2,
      isNew: false
    },
    {
      id: 5,
      name: "Wide-Leg Pants",
      price: "$145",
      category: "Bottoms",
      image: product1,
      isNew: true
    },
    {
      id: 6,
      name: "Midi Dress",
      price: "$175",
      category: "Dresses",
      image: product3,
      isNew: false
    }
  ];

  const filteredProducts = selectedCategory === "All" 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-playfair text-4xl md:text-5xl font-bold text-primary mb-4">
            Our Collection
          </h1>
          <p className="font-inter text-muted-foreground max-w-2xl mx-auto">
            Discover carefully curated pieces that blend timeless elegance with contemporary design
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className="font-inter"
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="group cursor-pointer border-0 shadow-card hover:shadow-elegant transition-all duration-300">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-lg mb-4">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {product.isNew && (
                    <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground">
                      New
                    </Badge>
                  )}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />
                  <Button 
                    variant="hero" 
                    size="lg"
                    className="absolute bottom-4 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  >
                    Quick View
                  </Button>
                </div>
                <div className="p-4 text-center space-y-2">
                  <h3 className="font-playfair text-xl font-medium text-primary">
                    {product.name}
                  </h3>
                  <p className="font-inter text-lg font-medium text-foreground">
                    {product.price}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="font-inter">
            Load More Products
          </Button>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Shop;